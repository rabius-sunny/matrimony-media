export const achieves = [
  {
    id: 1,
    number: '11230+',
    text: 'মোট দ্বীনদার পাত্র-পাত্রীর বায়োডাটা',
    img: 'https://ordhekdeen.com/wp-content/uploads/2022/02/Couple-v2.svg'
  },
  {
    id: 2,
    number: '6500+',
    text: 'মোট পাত্রের বায়োডাটা',
    img: 'https://ordhekdeen.com/wp-content/uploads/2022/02/Male-v2.svg'
  },
  {
    id: 3,
    number: '5034+',
    text: 'মোট পাত্রীর বায়োডাটা',
    img: 'https://ordhekdeen.com/wp-content/uploads/2022/02/Female-v2.svg'
  },
  {
    id: 4,
    number: '503',
    text: 'সর্বমোট সফল বিবাহ',
    img: 'https://ordhekdeen.com/wp-content/uploads/2022/02/Ring.svg'
  }
]
