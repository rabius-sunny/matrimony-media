"use strict";
exports.id = 815;
exports.ids = [815];
exports.modules = {

/***/ 2815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseURL = "http://localhost:5000";
const instance = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL,
    timeout: 10000
});
// Adding a request interceptor
instance.interceptors.request.use(function(config) {
    return {
        ...config,
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        }
    };
});
// Common function to get acctual data from response
const responseBody = (response)=>response.data
;
const requests = {
    get: (url)=>instance.get(url).then(responseBody)
    ,
    post: (url, body)=>instance.post(url, body).then(responseBody)
    ,
    patch: (url, body)=>instance.patch(url, body).then(responseBody)
    ,
    delete: (url)=>instance.delete(url).then(responseBody)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (requests);


/***/ })

};
;