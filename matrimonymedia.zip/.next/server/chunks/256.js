"use strict";
exports.id = 256;
exports.ids = [256];
exports.modules = {

/***/ 2412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/female.543a38ba.svg","height":50,"width":50});

/***/ }),

/***/ 4322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/male.d4a5658e.svg","height":50,"width":50});

/***/ }),

/***/ 7804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BioInfoCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./public/images/male.svg
var male = __webpack_require__(4322);
// EXTERNAL MODULE: ./public/images/female.svg
var female = __webpack_require__(2412);
// EXTERNAL MODULE: ./components/shared/CSkeleton.jsx
var CSkeleton = __webpack_require__(9257);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./utils/copyToClip.js
async function copyToClip(text) {
    if ("clipboard" in navigator) {
        return await navigator.clipboard.writeText(text);
    } else {
        return document.execCommand("copy", true, text);
    }
};

// EXTERNAL MODULE: ./components/shared/Modals/LongModal.jsx
var LongModal = __webpack_require__(3801);
// EXTERNAL MODULE: external "@nextui-org/react"
var react_ = __webpack_require__(6735);
// EXTERNAL MODULE: ./services/userRequest.js
var userRequest = __webpack_require__(223);
;// CONCATENATED MODULE: ./components/bio/BioInfoCard.jsx










function BioInfoCard({ data , loading , uId  }) {
    var ref, ref1, ref2;
    const { 0: id , 1: setId  } = (0,external_react_.useState)(null);
    const { 0: copy , 1: setCopy  } = (0,external_react_.useState)(false);
    const { 0: info1 , 1: setInfo  } = (0,external_react_.useState)({
        type: "",
        condition: "",
        permanent_address: "",
        permanent_division: "",
        current_address: "",
        current_division: "",
        birth: "",
        complexion: "",
        height: "",
        weight: "",
        blood: "",
        profession: ""
    });
    const { 0: _delete , 1: set_delete  } = (0,external_react_.useState)(false);
    const { 0: hide , 1: setHide  } = (0,external_react_.useState)(false);
    const HideAction = ()=>{
        const handleHide = ()=>{
            userRequest/* default.hideByUser */.Z.hideByUser().then((info)=>{
                if (info.message === "ok") {
                    setHide(false);
                    window.location.reload();
                }
            }).catch((err)=>{
                alert("\u0987\u09B0\u09B0 \u09B9\u09DF\u09C7\u099B\u09C7, \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8");
                setHide(false);
            });
        };
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "mb-4 italic text-yellow-500",
                    children: [
                        "\u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE \u201C\u09B9\u09BE\u0987\u09A1\u201D \u098F\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE\u099F\u09BF \u09B8\u09BE\u09B0\u09CD\u099A \u09AB\u09BF\u09B2\u09CD\u099F\u09BE\u09B0 \u09A5\u09C7\u0995\u09C7 \u0997\u09CB\u09AA\u09A8\u09C7 \u09B0\u09BE\u0996\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 \u09AA\u09B0\u09AC\u09B0\u09CD\u09A4\u09C0\u09A4\u09C7 \u09AF\u09C7 \u09AF\u09C7\u0995\u09CB\u09A8 \u09B8\u09AE\u09DF \u09AA\u09C1\u09A8\u09B0\u09BE\u09DF \u09AA\u09BE\u09AC\u09CD\u09B2\u09BF\u09B6 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8 ",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "\u0987\u09A8 \u09B6\u09BE \u0986\u09B2\u09CD\u09B2\u09BE\u09B9\u0964"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex gap-x-2 justify-end",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            bordered: true,
                            auto: true,
                            color: "success",
                            onPress: ()=>setHide(false)
                            ,
                            children: "\u09AB\u09BF\u09B0\u09C7 \u09AF\u09BE\u09A8"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            bordered: true,
                            auto: true,
                            color: "warning",
                            onPress: handleHide,
                            children: "\u09B9\u09BE\u0987\u09A1 \u0995\u09B0\u09C1\u09A8"
                        })
                    ]
                })
            ]
        });
    };
    const DeleteAction = ()=>{
        const { 0: reason , 1: setReason  } = (0,external_react_.useState)("");
        const handleDelete = (type)=>{
            if (reason !== "") {
                userRequest/* default.deleteHideRequest */.Z.deleteHideRequest({
                    reason,
                    type
                }).then((info)=>{
                    if (info.message === "ok") {
                        alert("\u0986\u09AA\u09A8\u09BE\u09B0 delete \u09B0\u09BF\u0995\u09C1\u09DF\u09C7\u09B8\u09CD\u099F\u099F\u09BF \u0997\u09C3\u09B9\u09C0\u09A4 \u09B9\u09DF\u09C7\u099B\u09C7, \u09B6\u09C0\u0998\u09CD\u09B0\u0987 SMS \u098F\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u09AB\u09B2\u09BE\u09AB\u09B2 \u09AA\u09C7\u09DF\u09C7 \u09AF\u09BE\u09AC\u09C7\u09A8 \u0987\u09A8\u09B6\u09BE \u0986\u09B2\u09CD\u09B2\u09BE\u09B9!");
                        set_delete(false);
                    }
                }).catch((err)=>{
                    alert("\u0987\u09B0\u09B0 \u09B9\u09DF\u09C7\u099B\u09C7, \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8");
                    set_delete(false);
                });
            } else alert("\u0995\u09BE\u09B0\u09A3 \u09AC\u09B0\u09CD\u09A3\u09A8\u09BE \u0995\u09B0\u09C1\u09A8");
        };
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "mb-4 font-semibold italic text-red-400",
                    children: "\u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE \u201C\u09A1\u09BF\u09B2\u09BF\u099F\u201D \u098F\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE \u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3\u09AD\u09BE\u09AC\u09C7 \u0993\u09DF\u09C7\u09AC\u09B8\u09BE\u0987\u099F \u09A5\u09C7\u0995\u09C7 \u09AE\u09C1\u099B\u09C7 \u09AB\u09C7\u09B2\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 \u09AF\u09BE \u09AA\u09B0\u09AC\u09B0\u09CD\u09A4\u09C0\u09A4\u09C7 \u09AB\u09BF\u09B0\u09BF\u09DF\u09C7 \u0986\u09A8\u09BE \u09B8\u09AE\u09CD\u09AD\u09AC \u09A8\u09BE\u0964"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "my-4 text-sm",
                    children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE \u09A1\u09BF\u09B2\u09BF\u099F \u0995\u09B0\u09A4\u09C7 \u09A8\u09BF\u09AE\u09CD\u09A8\u09CB\u0995\u09CD\u09A4 \u09AB\u09B0\u09CD\u09AE\u099F\u09BF \u09AA\u09C2\u09B0\u09A3\u09C7\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u0986\u09AC\u09C7\u09A6\u09A8 \u0995\u09B0\u09C1\u09A8\u0964"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "my-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        onChange: ({ target: { value  }  })=>setReason(value)
                        ,
                        placeholder: "\u09B8\u0982\u0995\u09CD\u09B7\u09C7\u09AA\u09C7 \u0995\u09BE\u09B0\u09A3 \u09AC\u09B0\u09CD\u09A3\u09A8\u09BE \u0995\u09B0\u09C1\u09A8...",
                        className: "border-gray-300 border-2 mb-2 w-full p-2 focus:border-blue-500 rounded-lg",
                        rows: "4"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex gap-x-2 justify-end",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            bordered: true,
                            auto: true,
                            color: "success",
                            onPress: ()=>set_delete(false)
                            ,
                            children: "\u09AB\u09BF\u09B0\u09C7 \u09AF\u09BE\u09A8"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            type: "submit",
                            bordered: true,
                            auto: true,
                            color: "error",
                            onPress: handleDelete,
                            children: "\u09A1\u09BF\u09B2\u09BF\u099F \u0995\u09B0\u09C1\u09A8"
                        })
                    ]
                })
            ]
        });
    };
    (0,external_react_.useEffect)(()=>{
        data && setInfo({
            type: data.type,
            condition: data.condition,
            permanent_address: data.permanent_address,
            permanent_division: data.permanent_division,
            current_address: data.current_address,
            current_division: data.current_division,
            birth: data.birth,
            complexion: data.complexion,
            height: data.height,
            weight: data.weight,
            blood: data.blood,
            profession: data.profession
        });
        const localId = localStorage.getItem("id");
        localId && setId(localId);
    }, [
        data
    ]);
    const handleCopy = (text)=>{
        copyToClip(text);
        setCopy(true);
        setTimeout(()=>{
            setCopy(false);
        }, 1000);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "rounded-md bg-red-500 p-4 text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(LongModal/* default */.Z, {
                        color: "error",
                        bodyColor: "error",
                        header: "\u09AA\u09CD\u09B0\u09CB\u09AB\u09BE\u0987\u09B2\u09C7 \u09A1\u09BF\u09B2\u09BF\u099F \u0995\u09B0\u09C1\u09A8",
                        visible: _delete,
                        onClose: ()=>set_delete(false)
                        ,
                        preventClose: false,
                        body: /*#__PURE__*/ jsx_runtime_.jsx(DeleteAction, {
                            action: "\u09A1\u09BF\u09B2\u09BF\u099F"
                        }),
                        blur: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(LongModal/* default */.Z, {
                        header: "\u09AA\u09CD\u09B0\u09CB\u09AB\u09BE\u0987\u09B2 \u09B9\u09BE\u0987\u09A1 \u0995\u09B0\u09C1\u09A8",
                        color: "warning",
                        bodyColor: "warning",
                        visible: hide,
                        onClose: ()=>setHide(false)
                        ,
                        preventClose: false,
                        body: /*#__PURE__*/ jsx_runtime_.jsx(HideAction, {}),
                        blur: true
                    }),
                    loading && !data ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                height: 150,
                                width: 150,
                                circle: true
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CSkeleton/* default */.Z, {
                                    height: 30,
                                    width: "100%"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            id && (data === null || data === void 0 ? void 0 : (ref = data.user) === null || ref === void 0 ? void 0 : ref._id) === id ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        height: "150px",
                                        width: "150px",
                                        src: info1.type === "\u09AA\u09BE\u09A4\u09CD\u09B0\u09C0\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE" ? female/* default */.Z : male/* default */.Z,
                                        alt: "profile avatar"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: "mt-2 text-xl text-white",
                                        children: [
                                            "Biodata ID",
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-5xl",
                                                children: uId
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between items-center md:px-8 mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                height: "60px",
                                                width: "60px",
                                                src: info1.type === "\u09AA\u09BE\u09A4\u09CD\u09B0\u09C0\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE" ? female/* default */.Z : male/* default */.Z,
                                                alt: "profile avatar"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "pl-3 text-xl text-left md:text-3xl text-white",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-sm sm:text-2xl font-semibold ",
                                                        children: "Biodata ID"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: " text-sm sm:text-2xl font-semibold",
                                                        children: [
                                                            '" ',
                                                            uId,
                                                            ' "'
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>handleCopy(uId)
                                                ,
                                                className: `block text-sm sm:text-md px-1 sm:px-4 rounded-md border-2 ${copy ? "border-red-800" : "border-white"} py-1 sm:py-2 font-bold text-white`,
                                                children: copy ? "Copied" : "Copy BioID"
                                            })
                                        })
                                    })
                                ]
                            }),
                            id && id === (data === null || data === void 0 ? void 0 : (ref1 = data.user) === null || ref1 === void 0 ? void 0 : ref1._id) ? /*#__PURE__*/ jsx_runtime_.jsx("div", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "item__holder2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE\u09B0 \u09A7\u09B0\u09A3"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.type
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09AC\u09C8\u09AC\u09BE\u09B9\u09BF\u0995 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.condition
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09B8\u09CD\u09A5\u09BE\u09DF\u09C0 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.permanent_address
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09B8\u09CD\u09A5\u09BE\u09DF\u09C0 \u09AC\u09BF\u09AD\u09BE\u0997"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.permanent_division
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.current_address
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8 \u09AC\u09BF\u09AD\u09BE\u0997"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.current_division
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u099C\u09A8\u09CD\u09AE\u09B8\u09A8 (\u0986\u09B8\u09B2)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.birth
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u0997\u09BE\u09A4\u09CD\u09B0\u09AC\u09B0\u09CD\u09A3"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.complexion
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u0989\u099A\u09CD\u099A\u09A4\u09BE"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.height
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u0993\u099C\u09A8"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.weight
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09B0\u0995\u09CD\u09A4\u09C7\u09B0 \u0997\u09CD\u09B0\u09C1\u09AA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.blood
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "\u09AA\u09C7\u09B6\u09BE"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: info1.profession
                                            })
                                        ]
                                    })
                                ]
                            }),
                            id && id === (data === null || data === void 0 ? void 0 : (ref2 = data.user) === null || ref2 === void 0 ? void 0 : ref2._id) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: ()=>handleCopy(uId)
                                            ,
                                            className: `block w-full rounded-md ${copy ? "bg-red-800" : "bg-white"} py-3 font-bold ${copy ? "text-white" : "text-red-600"} focus:ring-2 focus:ring-red-700`,
                                            children: copy ? "Copied" : "Copy BioID"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "btnHolder mt-4 flex rounded-md bg-white font-bold text-red-600",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>{
                                                    set_delete(true);
                                                },
                                                className: "font-semibold hover:bg-red-200",
                                                children: "Delete Biodata"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>{
                                                    setHide(true);
                                                },
                                                className: `font-semibold ${(data === null || data === void 0 ? void 0 : data.published) ? "cursor-pointer" : "pointer-events-none"} hover:bg-red-200`,
                                                children: "Hide Biodata"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${data ? "block" : "hidden"} my-4 ${(data === null || data === void 0 ? void 0 : data.published) ? "bg-green-600" : "bg-red-600"} shadow-lg py-2 text-white rounded text-2xl text-center`,
                children: (data === null || data === void 0 ? void 0 : data.published) ? "\u09AC\u09BE\u09DF\u09CB\u099F\u09BF \u09AA\u09BE\u09AC\u09B2\u09BF\u09B6\u09A1 \u09B0\u09DF\u09C7\u099B\u09C7" : "\u09AC\u09BE\u09DF\u09CB\u099F\u09BF \u09B9\u09BE\u0987\u09A1 \u09B0\u09DF\u09C7\u099B\u09C7"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${!data || (data === null || data === void 0 ? void 0 : data.published) ? "hidden" : "block"} bg-red-200 text-red-600 p-2 shadow font-semibold`,
                children: "\u09AA\u09BE\u09AC\u09B2\u09BF\u09B6 \u0995\u09B0\u09A4\u09C7 \u09AA\u09CD\u09B0\u09BF\u09AD\u09BF\u0989 \u09A5\u09C7\u0995\u09C7 \u09AA\u09BE\u09AC\u09B2\u09BF\u09B6 \u09B0\u09BF\u0995\u09C1\u09DF\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8"
            })
        ]
    });
};


/***/ }),

/***/ 8731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2815);

class BiodataRequests {
    getBios(type, jilla) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/home/${type}/${jilla}`);
    }
    filterBios(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/filter-bios", body);
    }
    getBioByUID(uId) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/bio-id/${uId}`);
    }
    getBioByToken() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/getbio-by-token");
    }
    updateBio(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/createorupdate-biodata", body);
    }
    setField(num) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/set-field/${num}`);
    }
    checkField() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/check-field");
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new BiodataRequests());


/***/ }),

/***/ 223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2815);

class UserRequests {
    signIn(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/sign-in", body);
    }
    getUser() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-user");
    }
    getType() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-type");
    }
    getFavorites() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/favorites");
    }
    checkFavorite(bioid) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/is-favorite/${bioid}`);
    }
    addToBookmark(id) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/post-favorites/${id}`);
    }
    removeBookmark(id) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/delete-favorites/${id}`);
    }
    getFeatureds() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-featureds");
    }
    makeRequest(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/request-info", body);
    }
    deleteHideRequest(reason) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/delete-hide-request", reason);
    }
    hideByUser() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/hide-by-user");
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new UserRequests());


/***/ })

};
;