"use strict";
exports.id = 491;
exports.ids = [491];
exports.modules = {

/***/ 2619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useAsync)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useAsync(asyncFunction) {
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const { 0: status , 1: setStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("pending");
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setStatus("pending");
        setData(null);
        setError(null);
        asyncFunction().then((res)=>{
            setData(res);
            setStatus("success");
            setError(null);
        }).catch((err)=>{
            setError(err);
            setStatus("error");
            setData(null);
        });
    }, [
        asyncFunction
    ]);
    return {
        data,
        error,
        isLoading: status === "pending",
        isSuccess: status === "success",
        isError: status === "error"
    };
};


/***/ }),

/***/ 223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2815);

class UserRequests {
    signIn(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/sign-in", body);
    }
    getUser() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-user");
    }
    getType() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-type");
    }
    getFavorites() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/favorites");
    }
    checkFavorite(bioid) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/is-favorite/${bioid}`);
    }
    addToBookmark(id) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/post-favorites/${id}`);
    }
    removeBookmark(id) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/delete-favorites/${id}`);
    }
    getFeatureds() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/get-featureds");
    }
    makeRequest(body) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/request-info", body);
    }
    deleteHideRequest(reason) {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/delete-hide-request", reason);
    }
    hideByUser() {
        return _http__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/hide-by-user");
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new UserRequests());


/***/ })

};
;