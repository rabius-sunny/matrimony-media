"use strict";
exports.id = 68;
exports.ids = [68];
exports.modules = {

/***/ 4068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ AppWrapper),
/* harmony export */   "b": () => (/* binding */ useAppContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const AppContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function AppWrapper({ children  }) {
    const { 0: errorState , 1: setErrorState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: routes , 1: setRoutes  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        primary: {
            name: "\u09AA\u09CD\u09B0\u09BE\u09A5\u09AE\u09BF\u0995",
            link: "/primary",
            status: ""
        },
        personal: {
            name: "\u09AC\u09CD\u09AF\u0995\u09CD\u09A4\u09BF\u0997\u09A4 \u09A4\u09A5\u09CD\u09AF",
            link: "/personal-info",
            status: ""
        },
        marriage: {
            name: "\u09AC\u09BF\u09DF\u09C7 \u09B8\u0982\u0995\u09CD\u09B0\u09BE\u09A8\u09CD\u09A4 \u09A4\u09A5\u09CD\u09AF",
            link: "/marriage-related-info",
            status: ""
        },
        general: {
            name: "\u09B8\u09BE\u09A7\u09BE\u09B0\u09A3 \u09A4\u09A5\u09CD\u09AF",
            link: "/general-info",
            status: ""
        },
        family: {
            name: "\u09AA\u09BE\u09B0\u09BF\u09AC\u09BE\u09B0\u09BF\u0995 \u09A4\u09A5\u09CD\u09AF",
            link: "/family-info",
            status: ""
        },
        address: {
            name: "\u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
            link: "/address",
            status: ""
        },
        education: {
            name: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE",
            link: "/educational-qualifications",
            status: ""
        },
        another: {
            name: "\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09A4\u09A5\u09CD\u09AF",
            link: "/others-info",
            status: ""
        },
        expectation: {
            name: "\u09AF\u09C7\u09AE\u09A8 \u099C\u09C0\u09AC\u09A8\u09B8\u0999\u09CD\u0997\u09C0 \u0986\u09B6\u09BE \u0995\u09B0\u09C7\u09A8",
            link: "/expectation",
            status: ""
        },
        // authority: {
        //   name: 'কর্তৃপক্ষের জিজ্ঞাসা',
        //   link: '/authority-question',
        // status: ''
        // },
        contact: {
            name: "\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997",
            link: "/contact-info",
            status: ""
        },
        contact: {
            name: "\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997",
            link: "/contact-info",
            status: ""
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppContext.Provider, {
        value: {
            errorState,
            setErrorState,
            routes,
            setRoutes
        },
        children: children
    });
}
function useAppContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AppContext);
}


/***/ })

};
;