"use strict";
exports.id = 722;
exports.ids = [722];
exports.modules = {

/***/ 8624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BioHeading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



function BioHeading({ heading , children , link  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "rounded-t-md overflow-hidden",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "border-x-4 border-b-4 border-red-500",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                    className: "flex justify-between bg-red-500 text-white text-xl sm:text-3xl p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: heading
                        }),
                        link && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: `/profile/edit/${link}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__.PencilAltIcon, {
                                className: "h-7 w-7 sm:h-10 sm:w-10 cursor-pointer hover:text-blue-500"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "p-4 item__holder",
                    children: children
                })
            ]
        })
    });
};


/***/ }),

/***/ 4208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DAddress)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DAddress({ data , auth  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        link: auth && "/address",
        heading: "\u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09B8\u09CD\u09A5\u09BE\u09DF\u09C0 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.permanent_address
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.current_address
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0995\u09CB\u09A5\u09BE\u09DF \u09AC\u09DC \u09B9\u09DF\u09C7\u099B\u09C7\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.where_lived
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 9274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DAnother)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DAnother({ auth , data: { profession_info , special_acknowledgement  }  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09A4\u09A5\u09CD\u09AF",
        link: auth && "/others-info",
        children: [
            profession_info && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AA\u09C7\u09B6\u09BE \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09BF\u09A4 \u09A4\u09A5\u09CD\u09AF"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: profession_info
                    })
                ]
            }),
            special_acknowledgement && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AC\u09BF\u09B6\u09C7\u09B7 \u0995\u09BF\u099B\u09C1 \u09AF\u09A6\u09BF \u099C\u09BE\u09A8\u09BE\u09A4\u09C7 \u099A\u09BE\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: special_acknowledgement
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 3420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DEducation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DEducation({ data , auth  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE",
        link: auth && "/educational-qualifications",
        children: data.education === "\u099C\u09C7\u09A8\u09BE\u09B0\u09C7\u09B2" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(General, {
            data: data
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Madrasha, {
            data: data
        })
    });
};
const General = ({ data  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0995\u09CB\u09A8 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u09AA\u09DC\u09BE\u09B6\u09CB\u09A8\u09BE \u0995\u09B0\u09C7\u099B\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.education
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09BF\u0995 (SSC) / \u09B8\u09AE\u09AE\u09BE\u09A8 \u09AA\u09BE\u09B6 \u0995\u09B0\u09C7\u099B\u09C7\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.secondary
                    })
                ]
            }),
            data.secondary === "\u09B9\u09CD\u09AF\u09BE" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09BF\u0995 (SSC) / \u09B8\u09AE\u09AE\u09BE\u09A8 \u098F\u09B0 \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.secondary_details
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0995\u09CB\u09A8 \u0995\u09CD\u09B2\u09BE\u09B8 \u09AA\u09B0\u09CD\u09AF\u09A8\u09CD\u09A4 \u09AA\u09DC\u09C7\u099B\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.whatclass
                    })
                ]
            }),
            data.secondary === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0989\u099A\u09CD\u099A\u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09BF\u0995 (HSC) / \u09B8\u09AE\u09AE\u09BE\u09A8 \u09AA\u09BE\u09B6 \u0995\u09B0\u09C7\u099B\u09C7\u09A8"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.higher
                            })
                        ]
                    }),
                    data.higher === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0989\u099A\u09CD\u099A\u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09BF\u0995 (HSC) / \u09B8\u09AE\u09AE\u09BE\u09A8 \u098F\u09B0 \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.higher_details
                            })
                        ]
                    }),
                    data.higher === "\u09A8\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0989\u099A\u09CD\u099A\u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09BF\u0995 (HSC) / \u09B8\u09AE\u09AE\u09BE\u09A8 \u0995\u09CB\u09A8 \u09AC\u09B0\u09CD\u09B7\u09C7 \u09AA\u09DC\u099B\u09C7\u09A8"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.higher_year
                            })
                        ]
                    }),
                    data.higher === "\u09A1\u09BF\u09AA\u09CD\u09B2\u09CB\u09AE\u09BE \u09AA\u09DC\u09C7\u099B\u09BF" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u09A1\u09BF\u09AA\u09CD\u09B2\u09CB\u09AE\u09BE \u098F\u09B0 \u09AC\u09BF\u09B7\u09DF\u09C7 \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.diploma_details
                            })
                        ]
                    })
                ]
            }),
            data.higher === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09B8\u09CD\u09A8\u09BE\u09A4\u0995/\u09B8\u09CD\u09A8\u09BE\u09A4\u0995(\u09B8\u09AE\u09CD\u09AE\u09BE\u09A8)/\u09B8\u09AE\u09AE\u09BE\u09A8 \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.honors_details
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.another_education
                    })
                ]
            })
        ]
    });
};
const Madrasha = ({ data  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u09B9\u09BE\u09AB\u09C7\u099C"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.hafej
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A6\u09BE\u0993\u09B0\u09BE\u09DF\u09C7 \u09B9\u09BE\u09A6\u09C0\u09B8 \u09AA\u09BE\u09B6 \u0995\u09B0\u09C7\u099B\u09C7\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.dawra
                    })
                ]
            }),
            data.dawra === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A6\u09BE\u0993\u09B0\u09BE\u09DF\u09C7 \u09B9\u09BE\u09A6\u09C0\u09B8 \u098F\u09B0 \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.dawra_details
                    })
                ]
            }),
            data.dawra === "\u098F\u0996\u09A8\u09CB \u09AA\u09DC\u09C7\u099B\u09BF" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A6\u09BE\u0993\u09B0\u09BE\u09DF\u09C7 \u09B9\u09BE\u09A6\u09C0\u09B8 \u0995\u09CB\u09A8 \u09AC\u09B0\u09CD\u09B7\u09C7 \u09AA\u09DC\u099B\u09C7\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.dawra_year
                    })
                ]
            }),
            data.dawra === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u09A4\u09BE\u0996\u09BE\u09B8\u09B8\u09C1\u09B8 \u09AA\u09DC\u09C7\u099B\u09C7\u09A8"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.takhassus
                            })
                        ]
                    }),
                    data.takhassus === "\u09B9\u09CD\u09AF\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u09A4\u09BE\u0996\u09BE\u09B8\u09B8\u09C1\u09B8 \u098F\u09B0 \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: data.takhassus_details
                            })
                        ]
                    })
                ]
            }),
            data.highest_education && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.highest_education
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: data.another_education
                    })
                ]
            })
        ]
    })
;


/***/ }),

/***/ 7195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DExpect)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DExpect({ auth , data: { ex_year , ex_complexion , ex_height , ex_education , ex_jilla , ex_marrital_condition , ex_profession , ex_financial_condition , ex_family_condition , ex_features  }  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u09AF\u09C7\u09AE\u09A8 \u099C\u09C0\u09AC\u09A8\u09B8\u0999\u09CD\u0997\u09C0 \u0986\u09B6\u09BE \u0995\u09B0\u09C7\u09A8",
        link: auth && "/expectation",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AC\u09DF\u09B8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_year
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0997\u09BE\u09A4\u09CD\u09B0\u09AC\u09B0\u09CD\u09A3 "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_complexion
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A8\u09C2\u09A8\u09CD\u09AF\u09A4\u09AE \u0989\u099A\u09CD\u099A\u09A4\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_height
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A8\u09C2\u09A8\u09CD\u09AF\u09A4\u09AE \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u0997\u09A4 \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_education
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u099C\u09C7\u09B2\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_jilla
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AC\u09C8\u09AC\u09BE\u09B9\u09BF\u0995 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_marrital_condition
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AA\u09C7\u09B6\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_profession
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0985\u09B0\u09CD\u09A5\u09A8\u09C8\u09A4\u09BF\u0995 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_financial_condition
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AA\u09BE\u09B0\u09BF\u09AC\u09BE\u09B0\u09BF\u0995 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: ex_family_condition
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u099C\u09C0\u09AC\u09A8\u09B8\u0999\u09CD\u0997\u09C0\u09B0 \u09AF\u09C7 \u09AC\u09C8\u09B6\u09BF\u09B7\u09CD\u099F\u09CD\u09AF \u09AC\u09BE \u0997\u09C1\u09A3\u09BE\u09AC\u09B2\u09BF \u0986\u09B6\u09BE \u0995\u09B0\u09C7\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: ex_features
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 5570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DFamily)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DFamily({ auth , data: { father_profession , mother_profession , brothers , brothers_info , sisters , sisters_info , uncles_profession , family_status  }  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u09AA\u09BE\u09B0\u09BF\u09AC\u09BE\u09B0\u09BF\u0995 \u09A4\u09A5\u09CD\u09AF",
        link: auth && "/family-info",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AA\u09BF\u09A4\u09BE\u09B0 \u09AA\u09C7\u09B6\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: father_profession
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AE\u09BE\u09A4\u09BE\u09B0 \u09AA\u09C7\u09B6\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: mother_profession
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AD\u09BE\u0987 \u0995\u09DF\u099C\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: brothers
                    })
                ]
            }),
            brothers && brothers !== "\u09AD\u09BE\u0987 \u09A8\u09C7\u0987" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AD\u09BE\u0987\u09A6\u09C7\u09B0 \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u09A4\u09A5\u09CD\u09AF"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: brothers_info
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AC\u09CB\u09A8 \u0995\u09DF\u099C\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: sisters
                    })
                ]
            }),
            sisters && sisters !== "\u09AC\u09CB\u09A8 \u09A8\u09C7\u0987" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AC\u09CB\u09A8\u09A6\u09C7\u09B0 \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u09A4\u09A5\u09CD\u09AF"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: sisters_info
                    })
                ]
            }),
            uncles_profession && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u099A\u09BE\u099A\u09BE-\u09AE\u09BE\u09AE\u09BE\u09A6\u09C7\u09B0 \u09AA\u09C7\u09B6\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: uncles_profession
                    })
                ]
            }),
            family_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AA\u09B0\u09BF\u09AC\u09BE\u09B0\u09C7\u09B0 \u0985\u09B0\u09CD\u09A5\u09A8\u09C8\u09A4\u09BF\u0995 \u0993 \u09B8\u09BE\u09AE\u09BE\u099C\u09BF\u0995 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: family_status
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 7713:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DMarital)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DMarital({ auth , data: { type , whenDiedWife , whenDiedHusband , divorceInfo , reMarryReason , guardians_permission , marry_reason , family_planning , education_after_marriage , job_after_marriage , demand  }  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u09AC\u09BF\u09DF\u09C7 \u09B8\u0982\u0995\u09CD\u09B0\u09BE\u09A8\u09CD\u09A4 \u09A4\u09A5\u09CD\u09AF",
        link: auth && "/marriage-related-info",
        children: [
            whenDiedWife && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09CD\u09A4\u09CD\u09B0\u09C0 \u0995\u09AC\u09C7, \u0995\u09BF\u09AD\u09BE\u09AC\u09C7 \u09AE\u09BE\u09B0\u09BE \u0997\u09BF\u09DF\u09C7\u099B\u09BF\u09B2 ?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: whenDiedWife
                    })
                ]
            }),
            divorceInfo && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09A1\u09BF\u09AD\u09CB\u09B0\u09CD\u09B8\u09C7\u09B0 \u09B8\u09AE\u09DF\u0995\u09BE\u09B2 \u0993 \u0995\u09BE\u09B0\u09A3"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: divorceInfo
                    })
                ]
            }),
            whenDiedHusband && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09CD\u09AC\u09BE\u09AE\u09C0 \u0995\u09AC\u09C7, \u0995\u09BF\u09AD\u09BE\u09AC\u09C7 \u09AE\u09BE\u09B0\u09BE \u0997\u09BF\u09DF\u09C7\u099B\u09BF\u09B2?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: whenDiedHusband
                    })
                ]
            }),
            reMarryReason && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AC\u09BF\u09AC\u09BE\u09B9\u09BF\u09A4 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09DF \u0986\u09AC\u09BE\u09B0 \u0995\u09C7\u09A8 \u09AC\u09BF\u09DF\u09C7 \u0995\u09B0\u09A4\u09C7 \u099A\u09BE\u099A\u09CD\u099B\u09C7\u09A8 ?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: reMarryReason
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0985\u09AD\u09BF\u09AD\u09BE\u09AC\u0995 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09BF\u09DF\u09C7\u09A4\u09C7 \u09B0\u09BE\u099C\u09BF \u0995\u09BF \u09A8\u09BE?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: guardians_permission
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AC\u09BF\u09DF\u09C7 \u0995\u09C7\u09A8 \u0995\u09B0\u099B\u09C7\u09A8? \u09AC\u09BF\u09DF\u09C7 \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A7\u09BE\u09B0\u09A3\u09BE \u0995\u09BF?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: marry_reason
                    })
                ]
            }),
            type === "\u09AA\u09BE\u09A4\u09CD\u09B0\u09C7\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pl-3 items py-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pb-2 font-bold",
                                children: "\u09AC\u09BF\u09DF\u09C7\u09B0 \u09AA\u09B0 \u09B8\u09CD\u09A4\u09CD\u09B0\u09C0\u0995\u09C7 \u09A8\u09BF\u09DF\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09B0\u09BF\u0995\u09B2\u09CD\u09AA\u09A8\u09BE \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4 \u09B2\u09BF\u0996\u09C1\u09A8"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-1 whitespace-pre-wrap",
                                children: family_planning
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0986\u09AA\u09A8\u09BF \u09AC\u09BE \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09B0\u09BF\u09AC\u09BE\u09B0 \u09AA\u09BE\u09A4\u09CD\u09B0\u09C0\u09AA\u0995\u09CD\u09B7\u09C7\u09B0 \u0995\u09BE\u099B\u09C7 \u09AF\u09CC\u09A4\u09C1\u0995/\u0989\u09AA\u09B9\u09BE\u09B0/\u0985\u09B0\u09CD\u09A5 \u0986\u09B6\u09BE \u0995\u09B0\u09AC\u09C7\u09A8 \u0995\u09BF\u09A8\u09BE?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: demand
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u09AC\u09BF\u09DF\u09C7\u09B0 \u09AA\u09B0 \u09AA\u09DC\u09BE\u09B6\u09CB\u09A8\u09BE \u0995\u09B0\u09A4\u09C7 \u0987\u099A\u09CD\u099B\u09C1\u0995?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: education_after_marriage
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u09AC\u09BF\u09DF\u09C7\u09B0 \u09AA\u09B0 \u099A\u09BE\u0995\u09B0\u09BF \u0995\u09B0\u09A4\u09C7 \u0987\u099A\u09CD\u099B\u09C1\u0995?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: job_after_marriage
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 5015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DPersonal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BioHeading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8624);


function DPersonal({ auth , data: { type , dress , beard , dress_over_ankle , salat , salat_duration , maintain_mahram , can_tilawat , mazhab , madhab , political_view , drama_cinnema , disease , deeni_effort , murid_of_peer , majar_view , favorite_books , favorite_scholars , special_qualifications , about_me  }  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BioHeading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        heading: "\u09AC\u09CD\u09AF\u0995\u09CD\u09A4\u09BF\u0997\u09A4 \u09A4\u09A5\u09CD\u09AF",
        link: auth && "/personal-info",
        children: [
            type === "\u09AA\u09BE\u09A4\u09CD\u09B0\u09C7\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u09B8\u09C1\u09A8\u09CD\u09A8\u09A4\u09BF \u09A6\u09BE\u0981\u09DC\u09BF \u0986\u099B\u09C7 \u0995\u09BF?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: beard
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\u0995\u09BE\u09AA\u09DC \u09AA\u09BE\u09DF\u09C7\u09B0 \u099F\u09BE\u0996\u09A8\u09C1\u09B0 \u09AA\u09DC\u09C7\u09A8?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: dress_over_ankle
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: type === "\u09AA\u09BE\u09A4\u09CD\u09B0\u09C7\u09B0 \u09AC\u09BE\u09DF\u09CB\u09A1\u09BE\u099F\u09BE" ? "\u0998\u09B0\u09C7\u09B0 \u09AC\u09BE\u0987\u09B0\u09C7 \u09B8\u09BE\u09A7\u09BE\u09B0\u09A3\u09A4 \u0995\u09C0 \u09A7\u09B0\u09A3\u09C7\u09B0 \u09AA\u09CB\u09B6\u09BE\u0995 \u09AA\u09DC\u09C7\u09A8" : "\u0998\u09B0\u09C7\u09B0 \u09AC\u09BE\u0987\u09B0\u09C7 \u09B8\u09BE\u09A7\u09BE\u09B0\u09A3\u09A4 \u0995\u09C0 \u09A7\u09B0\u09A3\u09C7\u09B0 \u09AA\u09CB\u09B6\u09BE\u0995 \u09AA\u09DC\u09C7\u09A8 (\u09AA\u09B0\u09CD\u09A6\u09BE\u09B0 \u09AC\u09BF\u09AC\u09B0\u09A3)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: dress
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AA\u09CD\u09B0\u09A4\u09BF\u09A6\u09BF\u09A8 \u09AA\u09BE\u0981\u099A \u0993\u09DF\u09BE\u0995\u09CD\u09A4 \u09B8\u09BE\u09B2\u09BE\u09A4 \u09AA\u09DC\u09BE \u09B9\u09DF?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: salat
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A8\u09BF\u09DF\u09AE\u09BF\u09A4 \u0995\u09A4 \u09B8\u09AE\u09DF \u09AF\u09BE\u09AC\u09A4 \u09B8\u09BE\u09B2\u09BE\u09A4 \u09AA\u09DC\u099B\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: salat_duration
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AE\u09BE\u09B9\u09B0\u09BE\u09AE/\u0997\u09BE\u09DF\u09B0\u09C7-\u09AE\u09BE\u09B9\u09B0\u09BE\u09AE \u09AE\u09C7\u09A8\u09C7 \u099A\u09B2\u09C7\u09A8 \u0995\u09BF?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: maintain_mahram
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09B6\u09C1\u09A6\u09CD\u09A7\u09AD\u09BE\u09AC\u09C7 \u0995\u09C1\u09B0\u0986\u09A8 \u09A4\u09BF\u09B2\u09BE\u0993\u09DF\u09BE\u09A4 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: can_tilawat
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0995\u09CB\u09A8 \u09AE\u09BE\u09AF\u09B9\u09BE\u09AC \u0985\u09A8\u09C1\u09B8\u09B0\u09A3 \u0995\u09B0\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: madhab
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AE\u09BE\u09AF\u09B9\u09BE\u09AC \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u09B8\u0982\u0995\u09CD\u09B7\u09C7\u09AA\u09C7 \u09B2\u09BF\u0996\u09C1\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: mazhab
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0995\u09CB\u09A8\u09CB \u09B0\u09BE\u099C\u09A8\u09C8\u09A4\u09BF\u0995 \u09A6\u09B0\u09CD\u09B6\u09A8 \u09A5\u09BE\u0995\u09B2\u09C7 \u09B2\u09BF\u0996\u09C1\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: political_view
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09A8\u09BE\u099F\u0995/\u09B8\u09BF\u09A8\u09C7\u09AE\u09BE/\u09B8\u09BF\u09B0\u09BF\u09DF\u09BE\u09B2/\u0997\u09BE\u09A8 \u098F\u09B8\u09AC \u09A6\u09C7\u0996\u09C7\u09A8 \u09AC\u09BE \u09B6\u09C1\u09A8\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: drama_cinnema
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u09AE\u09BE\u09A8\u09B8\u09BF\u0995 \u09AC\u09BE \u09B6\u09BE\u09B0\u09C0\u09B0\u09BF\u0995 \u0995\u09CB\u09A8\u09CB \u09B0\u09CB\u0997 \u0986\u099B\u09C7 \u0995\u09BF?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: disease
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "item",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u0995\u09CB\u09A8\u09CB \u09AA\u09C0\u09B0\u09C7\u09B0 \u09AE\u09C1\u09B0\u09BF\u09A6?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: murid_of_peer
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09A6\u09CD\u09AC\u09C0\u09A8\u09C7\u09B0 \u0995\u09CB\u09A8 \u09AC\u09BF\u09B6\u09C7\u09B7 \u09AE\u09C7\u09B9\u09A8\u09A4\u09C7 \u09AF\u09C1\u0995\u09CD\u09A4 \u0986\u099B\u09C7\u09A8?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1",
                        children: deeni_effort
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AE\u09BE\u099C\u09BE\u09B0 \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A7\u09BE\u09B0\u09A3\u09BE \u09AC\u09BE \u09AC\u09BF\u09B6\u09CD\u09AC\u09BE\u09B8 \u0995\u09BF?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: majar_view
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6\u09C7\u09B0 \u0985\u09A8\u09CD\u09A4\u09A4 \u09E9 \u099F\u09BF \u0987\u09B8\u09B2\u09BE\u09AE\u09C0 \u09AC\u0987\u09DF\u09C7\u09B0 \u09A8\u09BE\u09AE \u09B2\u09BF\u0996\u09C1\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1",
                        children: favorite_books
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6\u09C7\u09B0 \u0985\u09A8\u09CD\u09A4\u09A4 \u09E9 \u099C\u09A8 \u0986\u09B2\u09C7\u09AE\u09C7\u09B0 \u09A8\u09BE\u09AE \u09B2\u09BF\u0996\u09C1\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1",
                        children: favorite_scholars
                    })
                ]
            }),
            special_qualifications && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09AC\u09BF\u09B6\u09C7\u09B7 \u09A6\u09CD\u09AC\u09C0\u09A8\u09BF \u09AC\u09BE \u09A6\u09C1\u09A8\u09BF\u09DF\u09BE\u09AC\u09BF \u09AF\u09CB\u0997\u09CD\u09AF\u09A4\u09BE (\u09AF\u09A6\u09BF \u09A5\u09BE\u0995\u09C7)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: special_qualifications
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pl-3 items py-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-2 font-bold",
                        children: "\u09A8\u09BF\u099C\u09C7\u09B0 \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u0995\u09BF\u099B\u09C1 \u09B2\u09BF\u0996\u09C1\u09A8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-1 whitespace-pre-wrap",
                        children: about_me
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 2640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function useAuth() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const { 0: auth , 1: setAuth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const isAuth = localStorage.getItem("token") ? true : false;
        setAuth(isAuth);
    }, [
        router.pathname
    ]);
    return auth;
};


/***/ })

};
;